package com.example.codingbot

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class Msg(val role: String, val text: String, val error: Boolean = false)

object Api {
    private const val SYSTEM =
        "You are an expert software engineer and coding assistant. " +
        "Give correct, idiomatic, working code. Put all code in fenced code blocks " +
        "with a language tag. Explain briefly: first the solution, then key points. " +
        "When debugging, find the root cause, don't just patch symptoms. " +
        "Mention edge cases and security issues when relevant. Answer in the user's language."

    fun chat(key: String, model: String, history: List<Msg>): String {
        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 20000
        c.readTimeout = 120000
        c.doOutput = true
        c.setRequestProperty("content-type", "application/json")
        c.setRequestProperty("x-api-key", key)
        c.setRequestProperty("anthropic-version", "2023-06-01")

        val msgs = JSONArray()
        history.filter { !it.error }.forEach {
            msgs.put(JSONObject().put("role", it.role).put("content", it.text))
        }
        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", 4096)
            .put("system", SYSTEM)
            .put("messages", msgs)
        c.outputStream.use { it.write(body.toString().toByteArray()) }

        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val txt = stream.bufferedReader().readText()
        if (code !in 200..299) throw RuntimeException("HTTP $code: $txt")
        val arr = JSONObject(txt).getJSONArray("content")
        return buildString {
            for (i in 0 until arr.length()) {
                val b = arr.getJSONObject(i)
                if (b.optString("type") == "text") append(b.getString("text"))
            }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { ChatScreen() } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE) }
    var apiKey by remember { mutableStateOf(prefs.getString("key", "") ?: "") }
    var model by remember { mutableStateOf(prefs.getString("model", "claude-sonnet-5-5") ?: "claude-sonnet-5-5") }
    var showSettings by remember { mutableStateOf(apiKey.isBlank()) }

    val messages = remember { mutableStateListOf<Msg>() }
    var input by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size, loading) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size)
    }

    fun send() {
        val text = input.trim()
        if (text.isEmpty() || loading) return
        if (apiKey.isBlank()) { showSettings = true; return }
        messages.add(Msg("user", text))
        input = ""
        loading = true
        val snapshot = messages.toList()
        scope.launch {
            try {
                val reply = withContext(Dispatchers.IO) { Api.chat(apiKey, model, snapshot) }
                messages.add(Msg("assistant", reply))
            } catch (e: Exception) {
                messages.add(Msg("assistant", "Ошибка: ${e.message}", error = true))
            }
            loading = false
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Coding Bot") },
                actions = {
                    TextButton(onClick = { messages.clear() }) { Text("Очистить") }
                    TextButton(onClick = { showSettings = true }) { Text("⚙") }
                }
            )
        },
        bottomBar = {
            Row(
                Modifier.fillMaxWidth().padding(8.dp),
                verticalAlignment = Alignment.Bottom
            ) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Опиши задачу или вставь код…") },
                    maxLines = 6
                )
                Spacer(Modifier.width(8.dp))
                Button(onClick = { send() }, enabled = !loading) { Text("→") }
            }
        }
    ) { pad ->
        LazyColumn(
            state = listState,
            modifier = Modifier.padding(pad).fillMaxSize().padding(horizontal = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(messages) { MessageBubble(it) }
            item { if (loading) Text("Думаю…", color = Color.Gray, modifier = Modifier.padding(8.dp)) }
        }
    }

    if (showSettings) {
        var k by remember { mutableStateOf(apiKey) }
        var m by remember { mutableStateOf(model) }
        AlertDialog(
            onDismissRequest = { if (apiKey.isNotBlank()) showSettings = false },
            title = { Text("Настройки") },
            text = {
                Column {
                    OutlinedTextField(
                        value = k, onValueChange = { k = it },
                        label = { Text("Anthropic API key") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = m, onValueChange = { m = it },
                        label = { Text("Модель") }, singleLine = true
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    apiKey = k.trim(); model = m.trim()
                    prefs.edit().putString("key", apiKey).putString("model", model).apply()
                    showSettings = false
                }) { Text("Сохранить") }
            }
        )
    }
}

@Composable
fun MessageBubble(msg: Msg) {
    val isUser = msg.role == "user"
    val bg = when {
        msg.error -> Color(0xFF5A1F1F)
        isUser -> Color(0xFF1F3A5A)
        else -> Color(0xFF2A2A2A)
    }
    Column(
        Modifier.fillMaxWidth().background(bg, RoundedCornerShape(12.dp)).padding(10.dp)
    ) {
        // Нечётные сегменты после split("```") — это код
        msg.text.split("```").forEachIndexed { i, part ->
            if (i % 2 == 1) {
                CodeBlock(part.substringAfter('\n', part).trimEnd())
            } else if (part.isNotBlank()) {
                SelectionContainer { Text(part.trim(), fontSize = 15.sp) }
            }
        }
    }
}

@Composable
fun CodeBlock(code: String) {
    val clipboard = LocalClipboardManager.current
    Column(
        Modifier.fillMaxWidth().padding(vertical = 6.dp)
            .background(Color(0xFF111111), RoundedCornerShape(8.dp)).padding(8.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            TextButton(onClick = { clipboard.setText(AnnotatedString(code)) }) { Text("Копировать") }
        }
        SelectionContainer {
            Text(
                code,
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp,
                color = Color(0xFFB5E8A8),
                modifier = Modifier.horizontalScroll(rememberScrollState())
            )
        }
    }
}
