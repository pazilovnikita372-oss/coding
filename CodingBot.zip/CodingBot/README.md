# Coding Bot (Android, Kotlin + Compose)

Чат-бот для программирования на Claude API.

## Как собрать APK
1. Установи Android Studio (Koala или новее).
2. File → Open → выбери папку CodingBot, дождись Gradle Sync.
3. Build → Build APK(s). Файл: app/build/outputs/apk/debug/app-debug.apk
4. Кинь APK на телефон и установи (разреши установку из неизвестных источников).

## Первый запуск
Нажми ⚙ и вставь свой API-ключ с console.anthropic.com.
Модель по умолчанию: claude-sonnet-5-5 (можно поменять там же).

Ключ хранится только на устройстве. Для публикации в магазин лучше
вынести запросы на свой сервер, чтобы ключ не лежал в приложении.
